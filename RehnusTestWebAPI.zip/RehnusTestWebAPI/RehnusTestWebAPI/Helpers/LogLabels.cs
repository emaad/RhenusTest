﻿namespace RehnusTestWebAPI
{
    public class LogLabels
    {
        public const string Login = "LOGIN:";
        public const string Register = "REGISTER:";
        public const string MakeBet = "MAKEBET:";
    }
}
